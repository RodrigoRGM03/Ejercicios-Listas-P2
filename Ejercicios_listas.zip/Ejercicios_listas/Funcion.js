function mostrarContenido(id) {

    const secciones = [
        "ProductosDisponiblesyRetirados",
        "PareseImpares",
        "AprobadosyReprobados",
        "EliminaryOrdenarproductos",
        "ListadePalabras"
    ];

    secciones.forEach(seccion => {
        document.getElementById(seccion).innerHTML = "";
    });

  
    const contenido = document.getElementById(id);
    contenido.innerHTML = `<p>Contenido de la opción seleccionada: ${id}</p>`;
}


document.getElementById("boton1").addEventListener("click", () => mostrarContenido("ProductosDisponiblesyRetirados"));
document.getElementById("boton2").addEventListener("click", () => mostrarContenido("PareseImpares"));
document.getElementById("boton3").addEventListener("click", () => mostrarContenido("AprobadosyReprobados"));
document.getElementById("boton4").addEventListener("click", () => mostrarContenido("EliminaryOrdenarproductos"));
document.getElementById("boton5").addEventListener("click", () => mostrarContenido("ListadePalabras"));
